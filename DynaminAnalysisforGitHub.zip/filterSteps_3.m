function [Properties]=filterSteps_3(Properties)
% FILTERSTEPS uses Properties from Stepfinder to filter dynamin events.
% However, not all detected steps refer to dynamin assembly/scission. Only
% traces with an incline (assembly) followed by a decline (scission) are
% selected here.
% All thresholds were established to maximize the detection of real events
% and to reduce noise.

% Properties        properties extracted from AutoStepfinder used as input
%                   before filtering and as output after filtering

%                   Code written by Julia Lehrich,
%                   Matlab version R2019b, September 2024

for i=size(Properties,2):-1:1
    StepSize=Properties{4,i};
    if numel(StepSize) < 2 || numel(StepSize) > 12
        Properties(:,i)=[];
    else
        if  min(StepSize(1:end)) > -15
            Properties(:,i)=[];
        else
            if  numel(find(StepSize(1:end)<0)) > 4
            Properties(:,i)=[];
            else
            
            [a,b] = min(diff(StepSize));
               if a > 0 || StepSize(b+1) > 0 || StepSize(b) < 0
                Properties(:,i)=[];
               else
                   
            stepdir=StepSize(1:b);
            steplength=Properties{1,i}(1:b);
            stepdir(stepdir<0)=-1;
            stepdir(stepdir>0)=1;
            
            if min(stepdir)<0
                negstep=find(stepdir<0);
                posstep=find(stepdir>0);
                dwell_neg=steplength(negstep);
                x=find(dwell_neg>25,1,'last');
                if isempty(x)==1
                    increase=posstep(1):numel(stepdir);
                else
                    y=find(posstep>negstep(x),1,'first');
                    increase=posstep(y):numel(stepdir);
                end
            else
                increase=1:numel(stepdir);
            end            
            
            steplengthInc=steplength(increase);
            maxdwelltime=120; %60 for optosplit, 120 for non-optosplit
            [increaselength,ilind]=find(steplengthInc>maxdwelltime);
            
            if isempty(increaselength)==0
                if length(increase)>length(ilind)
                    increase=increase(ilind(length(ilind))+1:end);
                else
                    increase=b;
                end
            end
            if isempty(increase)
                increase=b;
            end
            
            startevent=Properties{3,i}(increase(1));
            endevent=Properties{3,i}(b+1);
            Properties{8,i}=startevent;
            Properties{9,i}=endevent;
            %Properties{10,i}=amplitude;
               end
            end
       end
    end
 end
end