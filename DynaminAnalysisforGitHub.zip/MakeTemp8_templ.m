function [Lsg1,Lsg2,Lsg1SubSub,Lsg2SubSub]=MakeTemp8_templ(EVektor,Template,Image,Tsub11,Tsub55,guessx,guessy,del,CutIsize,threshtemplate)
% MAKETEMP8_TEMPL is the template matching algorithm, which compares a
% stack of templates with the measured PSF of a fluorophore to find its
% localization. The templates are shifted by sub-pixel distances to yield
% sub-pixel localization precision

% EVektor       unity vector
% Template      experimentally derived PSF
% Image         original image containing fluorophore signal to be
%               localized
% Tsub11        stack of templates with large shift distance
% Tsub55        stack of templates with small shift distance
% guessx        starting point for localization procedure in x ('guessed'
%               position)
% guessy        starting point for localization procedure in y ('guessed'
%               position)
% del           events to be deleted
% CutIsize      size of the cutout region for image segmentation
% threshtemplate    threshold for template matching algorithm
% Lsg1, Lsg2    localization coordinates from first set of templates Tsub11
% Lsg1SubSub, Lsg2SubSub
%               localization coordinates from second set of templates
%               Tsub55

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% allocation of matrices
cutl=fix(CutIsize/2);
numObj=numel(guessx);
Lsg1=zeros(1,numObj);
Lsg2=zeros(1,numObj);
Lsg1SubSub=zeros(1,numObj);
Lsg2SubSub=zeros(1,numObj);

%% template matching-based peak fitting
if numObj>=1
    %tic;
    for k = 1 : numObj
        a=guessx(k);
        b=guessy(k);
        CutI=Image((b-cutl):(b+cutl),(a-cutl):(a+cutl));
        CutI=mat2gray(CutI);
        
        Sub = sum(sum(bsxfun(@minus,Tsub11,CutI).^2)); 
        Sub = shiftdim(Sub);
        [Val,Ind]=min(Sub);

        Lsg1(k)=a-0.5+((Ind-1)-(fix((Ind-1)/11)*11))*0.1;
        Lsg2(k)=b-0.5+((fix((Ind-1)/11))*0.1);
    
        solve=((((fix((Ind-1)/11))-1)*61*5+61*5)+((Ind-1)-((fix((Ind-1)/11)*11))-1)*5+5);
        m=1:10;
    
        t5=(solve+m)'*EVektor+61*(EVektor'*m-1);
        Tsubsub=Tsub55(:,:,t5);                                            
    
        Sub2 = sum(sum(bsxfun(@minus,Tsubsub,CutI).^2)); 
        Sub2 = shiftdim(Sub2);
        [Val2,Ind2]=min(Sub2);
        if Val2>threshtemplate
            Lsg1(k)=0;
            Lsg2(k)=0;
            Lsg1SubSub(k)=0;
            Lsg2SubSub(k)=0;
        else
            Lsg1SubSub(k)=a-0.5+((Ind-1)-(fix((Ind-1)/11)*11))*0.1 - 0.1+((Ind2-1)-(fix((Ind2-1)/10)*10))*0.02;
            Lsg2SubSub(k)=b-0.5+((fix((Ind-1)/11))*0.1) - 0.1+((fix((Ind2-1)/11))*0.02);
        end
        %end
    end
    Lsg1(Lsg1<=0)=[];
    Lsg2(Lsg2<=0)=[];
    Lsg1SubSub(Lsg1SubSub<=0)=[];
    Lsg2SubSub(Lsg2SubSub<=0)=[];
end
n=numel(del);
for m=1:n
end

end

