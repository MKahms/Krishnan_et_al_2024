function [Tsub11,Tsub55,Template]=create_Tsubs7(accuracy1,accuracy2,xPSF,CutIsize)
% CREATE_TSUBS7 generates the stacks of templates used for the template
% matching algorithm. The stacks of templates consist of laterally shifted
% versions of the experimentally derived PSF. The templates are shifted by
% a distance defined by accuracy1 and accuracy2.

% accuracy1     accuracy for the first set of templates, usually set to
%               0.1 pixels 
% accuracy2     accuracy for the second set of templates, usually set to
%               0.02 pixels 
% xPSF          specific PSF parameters calculated for each camera by
%               fitting a Gaussian function to measured beads
% CutIsize      size of the cutout region for image segmentation
% Tsub11        stack of templates with shift distance defined by accuracy1
% Tsub55        stack of templates with shift distance defined by accuracy2
% Template      experimentally derived PSF

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% create first stack of templates shifted by accuracy1
x02=CutIsize/2;
y02=CutIsize/2;

Tsub11 = zeros(CutIsize,CutIsize,((1/accuracy1)+1)*((1/accuracy1)+1));
lauf=0;
for h = 1:(1.1/accuracy1) 
  for k = 1:(1.1/accuracy1) 
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsub11(i,j,lauf+k)=(xPSF(4)*exp(-((((i-(x02-accuracy1+h*accuracy1)).^2)+(j-(y02-accuracy1+k*accuracy1)).^2))/(2*xPSF(1).^2)))+xPSF(5);
        end
    end
    Tsub11(:,:,lauf+k)=mat2gray(Tsub11(:,:,lauf+k));
  
  end
lauf=lauf+k; 
end

%% create second stack of templates shifted by accuracy2
Tsub55 =zeros(CutIsize,CutIsize,(((1.1/accuracy2)+(0.1/accuracy2)+1) * ((1.1/accuracy2)+(0.1/accuracy2)+1)));
Tsub55x=zeros(CutIsize,CutIsize,((((1.1/accuracy2)+1) * ((1.1/accuracy2)+1))));
lauf=0;
for h = 1:(1.1/accuracy2) + 1
  for k = 1:(1.1/accuracy2) + 1
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsub55x(i,j,lauf+k)=(xPSF(4)*exp(-((((i-(x02-accuracy2+h*accuracy2)).^2)+(j-(y02-accuracy2+k*accuracy2)).^2))/(2*xPSF(1).^2)))+xPSF(5);       
        end
    end
    Tsub55x(:,:,lauf+k)=mat2gray(Tsub55x(:,:,lauf+k));
  
  end
lauf=lauf+k; 
end

for j=1:56
    for i=1:56
Tsub55(:,:,(305+i+5+61*(j-1)))=Tsub55x(:,:,i+56*(j-1));
    end
end

%% create image of experimentally derived PSF
Tsub = zeros(CutIsize,CutIsize,((1/accuracy1)+1)*((1/accuracy1)+1));
lauf=0;
for h = 1:(1.1/accuracy1) 
  for k = 1:(1.1/accuracy1) 
    for j = 1:CutIsize
        for i=1:CutIsize
            Tsub(i,j,lauf+k)=(xPSF(4)*exp(-((i-(x02-accuracy1+h*accuracy1)).^2+(j-(y02-accuracy1+k*accuracy1)).^2)/(2*xPSF(1).^2)))+xPSF(5);
        end
    end
    Tsub(:,:,lauf+k)=mat2gray(Tsub(:,:,lauf+k));
  
  end
lauf=lauf+k; 
end

Template=zeros(CutIsize,CutIsize);
for i = 1:CutIsize
    for j=1:CutIsize
        Template(i,j) = Tsub(i,j,61);
    end
end

end