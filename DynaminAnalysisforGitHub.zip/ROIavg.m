function [cuti_stim,cuti_trunc,cuti_trunc_avg,cuti_Int,cuti_Int_avg]=ROIavg(ResultEventInt_good,binning_trace,framerate,frameend)
% ROIAVG is  written for the use with the OptoSplit movies where
% Dynamin-GFP is simultaneously imaged with Clathrin or actin in the red
% channel. It is used to generate the averaged event traces for Dynamin
% and the other endocytic protein aligned in space and time. Here the  
% respective channels have been previously aligned and split using 
% imTransform.m and WriteTiffStacks.m. The Dynamin half of the channels is 
% used to extract the event coordinates and properties using  
% DynaminAnalysisforSteps.m. The Clathrin and Actin channel are read into 
% this programme and the event coordinates (ResultEventInt_good) and
% scission frame (frameend) from Dynamin are used to generate the averaged
% trace. 

% ResultEventInt_good   the resulting coordinates from
%                       DynaminAnalysisforSteps.m
% frameend              the event trace scission frame generated in
%                       DynaminAnalysisforSteps.m
% binning_trace         temporal binning factor for trace analysis,  
%                       typically a value of 5 was used
% framerate             framerate of measurement, typically was set to 50Hz 
%                       if an optosplit was introduced into the lightpath; 
%                       otherwise it was set to 100Hz
% A                     aligned and split movie of a protein imaged
%                       simultaneously with Dynamin using an image
%                       splitter.

% cuti_stim             cutout image at the scission frame based on 
%                       ResultEventInt_good
% cuti_trunc            subset of cuti_stim, truncated in time around the
%                       timepoint of scission
% cuti_trunc_avg        average of cuti_trunc at all localizations
% cuti_Int              intensity trace based on cuti_trunc
% cuti_Int_avg          intensity trace based on cuti_trunc_avg

%                       Code written by Julia Lehrich,
%                       Matlab version R2019b, September 2024

%%
[A] = imreadtiff;
timevec_trace=(1:(size(A,3)/binning_trace)).*((1/framerate)*binning_trace);

%% Cut out 3x3 px ROI for each event
B_2=reshape(A,size(A,1),size(A,2),binning_trace,size(A,3)./binning_trace);
B_avg_2=squeeze(round(mean(B_2,3)));

%% cut out the detected events and generate the traces averaged around scission i.e.frameend
CutIsize=3;
timevec_trace_trunc=cat(2,-(timevec_trace(99:-1:1)),0,timevec_trace(1:75));
cuti_stim=zeros(CutIsize,CutIsize,size(B_avg_2,3),size(ResultEventInt_good,2));
j=0;
for i=1:size(ResultEventInt_good,2)
    cuti_stim(:,:,:,i)=B_avg_2(round(ResultEventInt_good(3,i))-(floor(CutIsize/2)):round(ResultEventInt_good(3,i))+(floor(CutIsize/2)),round(ResultEventInt_good(2,i))-(floor(CutIsize/2)):round(ResultEventInt_good(2,i))+(floor(CutIsize/2)),:);
    if frameend(i)+20 <= size(B_avg_2,3)
        j=j+1;
        cuti_trunc(:,:,:,j)=cuti_stim(:,:,frameend(i)-99:frameend(i)+20,i);
    end
end
cuti_trunc_avg=squeeze(sum(cuti_trunc,4))./size(cuti_trunc,4);
cuti_Int=squeeze(sum(sum(cuti_trunc,1),2));
cuti_Int_avg=squeeze(sum(sum(cuti_trunc_avg,1),2));
figure, plot(timevec_trace_trunc,cuti_Int_avg);

%% Normalized visualization of averaged pixel area (to be used with CutIsize=7)  
cuti_trunc_avg_7=cuti_trunc_avg;
maxI=max(max(max(cuti_trunc_avg_7)));
minI=min(min(min(cuti_trunc_avg_7)));
figure, imagesc(cuti_trunc_avg_7(:,:,95), [minI maxI]); colormap(jet)
figure, imagesc(cuti_trunc_avg_7(:,:,30), [minI maxI]); colormap(jet)
figure, imagesc(cuti_trunc_avg_7(:,:,20), [minI maxI]); colormap(jet)
end