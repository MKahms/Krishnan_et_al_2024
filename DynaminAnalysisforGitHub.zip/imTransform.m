function [Aleft,Arightcor,fname,dirname,w,transf]=imTransform(varargin)
% IMTRANSFORM is an intensity-based image registration routine written for
% the use with the OptoSplit. The image containing both channels is read in
% and chopped in the middle (vertically). To this end, the camera should
% always be illuminated using the whole width (height is arbitrary). 
% The geometric transformation is always performed on the right image, the
% left channel is fixed.

% Aleft             chopped image (left half of camera, no transformation) 
% Arightcor         chopped and transformed right half of camera
% fname             name of the analyzed image stack
% dirname           directory where the analyzed image stack is saved

%                   Code written by Julia Lehrich,
%                   Matlab version R2019b, September 2024

%% initial setup
parpool;
[optimizer, metric] = imregconfig('multimodal');
optimizer.InitialRadius = 0.009;
optimizer.Epsilon = 1.5e-4;
optimizer.GrowthFactor = 1.01;
optimizer.MaximumIterations = 300;
%% read in images with beads for correction and perform image registration
msgbox('Reading of bead image','modal');
[beadsBefore]=imreadtiffpar;
Imleft=beadsBefore(:,11:(size(beadsBefore,2))/2-10,:);
Imright=beadsBefore(:,((size(beadsBefore,2))/2)+11:end-10,:);
coordinates=zeros(3,3,3);
parfor i=1:size(Imleft,3)
tform(i)=imregtform(Imright(:,:,i),Imleft(:,:,i),'rigid',optimizer,metric);
coordinates(:,:,i)=tform(i).T;
end
coordinates=mean(coordinates,3);
transf=tform(1);
transf.T=coordinates;
%% read in measurement, chop and apply geometric transformation on right channel
msgbox('Reading of measurement stack','modal');
[A,fname,dirname,w]=imreadtiffpar;
Aleft=A(:,1:(size(A,2))/2,:);
Aright=A(:,((size(A,2))/2)+1:end,:);
Arightcor = imwarp(Aright,transf,'OutputView',imref2d(size(Aright)));
poolobj = gcp('nocreate');
delete(poolobj);
end