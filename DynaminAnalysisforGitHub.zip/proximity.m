function [distframe,tempdist]=proximity(Result,distmax,stimlength,exptime)
% PROXIMITY calculates the time between fusion events occuring in close
% proximity. The maximum distance between fusion events considered for this
% analysis is defined by DISTMAX, and the time between fusion events
% occuring in close proximity is written into vector TEMPDIST.

% Result        matrix containing the intensities (1st row), x-positions
%               (2nd row), y-positions (3rd row) and frame number in the
%               difference image DiffIm, or number of stimulation pulse
%               (4th row). The matrix is generated using the APALM analysis
%               with the function phluorinhistogram.m
% distmax       maximum distance between fusion events used for temporal
%               distance analysis
% stimlength    number of frames between two stimuli (10 for 10 Hz
%               stimulation, 50 for 2 Hz stimulation)
% exptime       exposure time of a single camera frame

% distframe     matrix containing the frame numbers of events detected in
%               close proximity
% tempdist      vector containing the temporal distances between fusion
%               event detection in the same area

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% matrix blow-up
%in order to circumvent for loops, create large matrices and perform
%calculations all simultaneously. 
Shiftx=gallery('circul',Result(2,:));
a=Shiftx(1,:);
b=Shiftx(2:end,:);
c=cat(1,b,a);
shiftx=flipdim(c,1);
clear a b c Shiftx

Shifty=gallery('circul',Result(3,:));
a=Shifty(1,:);
b=Shifty(2:end,:);
c=cat(1,b,a);
shifty=flipdim(c,1);
clear a b c Shifty

check=gallery('circul',(1:size(Result,2)));
a=check(1,:);
b=check(2:end,:);
c=cat(1,b,a);
d=flipdim(c,1);
check=d;
clear a b c d

%% calculate distance between localized events
%blow up the original vectors (x-position, y-position, framenumber) by
%copying entries N-times (N = size(Result,2), number of events found).
%Thus, every element in Static can be subtracted from every other element
%in Shift.
Staticx=repmat(Result(2,:),size(Result,2),1);
Staticy=repmat(Result(3,:),size(Result,2),1);

%Calculate total distance of two events (pythagoras of x- and y-distance)
dist=sqrt((Staticx - shiftx).^2 + (Staticy - shifty).^2);

%% reject events with distances above distmax
distmask=dist;
distmask(dist<=distmax)=1;
distmask(dist>distmax)=0;
distmask2=flip(triu(flip(distmask,2)),2);
%analyse events only once. As each events is compared to all other events,
%each pair will be detected twice. To remove the double detection, flip the
%matrix dist and only regard the upper triangle (flipping is necessary to
%be able to use the function triu).

%find frames in which events are found
distframe=distmask2.*check;

%% determine the temporal distance between accepted events
%pairs contains the eventnumbers of events in close proximity to each
%other. framedist contains the according framenumber in DiffIm, that is the
%number of stimulation pulses given. Dependent on the stimulation
%frequency, the refractory period between those events in close proximity
%can be calculated by multiplying the framenumber by the number of frames
%between two stimuli and the exposure time of a single frame.
framedist=cell.empty(1,0);
tempdist_prev=cell.empty(1,0);
tempdist=[];
for i=1:size(distframe,1)
    pairs=unique(distframe(:,i));
    if numel(pairs)>2
    framedist{i}=Result(4,pairs(2:end));
    tempdist_prev{i}=abs((repmat(framedist{i}(1),[1 numel(framedist{i})-1]) - framedist{i}(2:end))).*stimlength.*exptime;
    tempdist=cat(2,tempdist,tempdist_prev{i});
    end
end

%% plot histogram of temporal distances
if numel(tempdist)==0
    maxval=1800;
else
    maxval=max(tempdist);
end
%figure, hist(tempdist,100:100:maxval)
end