function WriteTiffStacks(input, suffix, frames, output_directory)
% WRITETIFFSTACKS is used to save two split and aligned halves generated in
% imTransform.m

% input                 new name of either left or right Optosplit half
% suffix                If you don't want to concatenate suffix, write ''
%                       for suffix
% frames                previously generated image stacks from
%                       imTransform.m
% output_directory      directory where output files are saved

%                       Code written by Julia Lehrich,
%                       Matlab version R2019b, September 2024

    cd(output_directory);
    frames = uint16(frames);
    film_l = length(frames(1, 1, :));
    for i = 1 : film_l
        if (i == 1)
            imwrite(frames(:, :, i), strcat(input, suffix, '.tif'));
            states = fprintf('\n * Write TiffStacks 1 of %d', film_l);
        else
            imwrite(frames(:, :, i), strcat(input, suffix, '.tif'), 'WriteMode', 'append');
            if (mod(i, 1) == 0)
                fprintf(repmat('\b', 1, states))
                states = fprintf(' * Write TiffStacks %d of %d', i, film_l);
            end
        end
    end
    fprintf('\n');
end 