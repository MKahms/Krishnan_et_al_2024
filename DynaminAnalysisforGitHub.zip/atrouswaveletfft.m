function [P12,P23,P34,P45,P56] = atrouswaveletfft(Image,fftkernel1,fftkernel2,fftkernel3,fftkernel4,fftkernel5,fftkernel6)
% ATROUSWAVELETFFT multiplication of � trous kernel and image in fourier
% space, making use of the fast fourier transformation

% Image         Image to be filtered
% fftkernel1    wavelet filtering kernel without holes
% fftkernel2... wavelet filtering kernel with increasing size of holes
% P23           first wavelet plane containing fine structures (in momentum
%               space; with high frequencies in fourier space)
% P34           second wavelet plane
% P45           third wavelet plane
% P56           fourth wavelet plane containing large stuctures (in
%               momentum space; with low frequencies in fourier space

%               Code written by Julia Lehrich,
%               Matlab version R2019b, September 2024

%% multiplication of image and kernel in fourier space
fftimage = fft2(Image);
fftblurimage1 = fftimage.*fftkernel1; A1 = circshift(ifft2(fftblurimage1),[-2 -2]); 
fftblurimage2 = fftblurimage1.*fftkernel2; A2 = circshift(ifft2(fftblurimage2),[-6 -6]); 
fftblurimage3 = fftblurimage2.*fftkernel3; A3 = circshift(ifft2(fftblurimage3),[-14 -14]);
fftblurimage4 = fftblurimage3.*fftkernel4; A4 = circshift(ifft2(fftblurimage4),[-30 -30]);
fftblurimage5 = fftblurimage4.*fftkernel5; A5 = circshift(ifft2(fftblurimage5),[-62 -62]);
A6 = A5;

%% creation of wavelet planes
W1=Image-A1;
W2=A1-A2;
W3=A2-A3;
W4=A3-A4;
W5=A4-A5;
W6=A5-A6;

%% thresholding of � trous wavelet filtered image
sigma1=mad(reshape(W1,1,(size(W1,1)*size(W1,2))),1)/0.67;
sigma2=mad(reshape(W2,1,(size(W2,1)*size(W2,2))),1)/0.67;
sigma3=mad(reshape(W3,1,(size(W3,1)*size(W3,2))),1)/0.67;
sigma4=mad(reshape(W4,1,(size(W4,1)*size(W4,2))),1)/0.67;
sigma5=mad(reshape(W5,1,(size(W5,1)*size(W5,2))),1)/0.67;
sigma6=mad(reshape(W6,1,(size(W6,1)*size(W6,2))),1)/0.67;
W1(W1<=(3*sigma1))=0;
W2(W2<=(3*sigma2))=0;
W3(W3<=(3*sigma3))=0;
W4(W4<=(3*sigma4))=0;
W5(W5<=(3*sigma5))=0;
W6(W6<=(3*sigma6))=0;

%% creation of wavelet scales
P12=W1.*W2;
P23=W2.*W3;
P34=W3.*W4;
P45=W4.*W5;
P56=W5.*W6;
end

