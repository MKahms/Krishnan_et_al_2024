function [ResultEventFrNr]=Dynamin_proximity(Resultsortframe)
% DYNAMIN_PROXIMITY removes overlapping localizations within same frame 
% (axial proximity) as well as overlapping localizations across movie
% (temporal proximity)

% Resultsortframe   matrix containing the intensities (1st row),
%                   x-positions (2nd row), y-positions (3rd row) and frame
%                   number of detected events; sorted by frame number
% ResultEventFrNr   filtered matrix Resultsortframe

%                   Code written by Julia Lehrich,
%                   Matlab version R2019b, September 2024

%% Calculate proximity matrix (same frame proximity)(removes localization within same frame which overlap)
ROIsize1=5;
[distframe,tempdist]=proximity(Resultsortframe,ROIsize1,1,10);
%replace localization number with frame number in matrix distframe:
Distframenr=changem(distframe,Resultsortframe(4,:),1:length(Resultsortframe));
% Remove localizations close to each other within same frame
for i=1:length(Distframenr)
    DistframenrNonzero{i}=nonzeros(Distframenr(:,i));
    DistframeNonzero{i}=nonzeros(distframe(:,i));
    %find number of nearby localizations in same frame. idx is index of 
    %last localization in the same frame
    idx=find(DistframenrNonzero{i}==DistframenrNonzero{i}(1),1,'last');
    %keep nearby localizations in same frame
    idxkeep=[];
    if idx>1
        idxkeep=1:idx;
    end
    %create cell with localization number of occurances in close proximity
    %in same frame
    Sameframeloc{i}=DistframeNonzero{i}(idxkeep,:)';
end
%write localizations occuring in close proximity in same frame into vector 
Samefrloc=cell2mat(Sameframeloc);
%and delete from Result matrix
Resultsortframermv2=Resultsortframe;
Resultsortframermv2(:,Samefrloc)=0;
Resultsortframermv2=sortrows(Resultsortframermv2',4)';
index=find(Resultsortframermv2(1,:)>0,1,'first'); %find the first nonzero element
Resultsortframermv2=Resultsortframermv2(:,index:end);
%% Calculate proximity matrix (temporal proximity)(work with cleared matrix)(proximity with events across movie)
ROIsize2=3;
[distframetemp,tempdist]=proximity(Resultsortframermv2,ROIsize2,1,10);

%replace localization number with intensity in matrix distframe (to avoid 
%loop for assigning intensity):
DistframetempInt=changem(distframetemp,Resultsortframermv2(1,:),1:length(Resultsortframermv2));

ResultEvent=[];
IndEvent=[];
Distfrnorep=[];
distfrnorep=[];
for i=1:length(DistframetempInt)
    %create cell with all nonzero events, with loc number as first column:
    DistframetempNonzero{i}(:,1)=nonzeros(distframetemp(:,i));
    %...and intensity as second column:
    DistframetempNonzero{i}(:,2)=nonzeros(DistframetempInt(:,i));
end
for i=1:length(distframetemp)
    for j=length(distframetemp):-1:(i+1)
        if isempty(DistframetempNonzero{1,j})==0 && isempty(DistframetempNonzero{1,i})==0 && sum(ismember(DistframetempNonzero{1,i}(:,1),DistframetempNonzero{1,j}(:,1)))>0
            if isempty(distfrnorep)==1
                distfrnorep=cat(1,distfrnorep,DistframetempNonzero{1,i},DistframetempNonzero{1,j});
            else
                distfrnorep=cat(1,distfrnorep,DistframetempNonzero{1,j});
            end
            DistframetempNonzero{1,j}=[];
        end
    end
    if isempty(distfrnorep)==1 && isempty(DistframetempNonzero{1,i})==0
        distfrnorep=DistframetempNonzero{1,i};
    end
    Distfrnorep{i}=distfrnorep;
    distfrnorep=[];
    DistframetempNonzero{1,i}=[];
    %sort localizations by intensity:
    if isempty(Distfrnorep{i})==0
        Distfrnorep{i}=sortrows(Distfrnorep{i},2);
        %find the index of the last (i.e. the brightest) localization:
        indmax(i)=find(Distfrnorep{i}(:,2),1,'last');
        %prevent double selection of events:
        if ismember(Distfrnorep{i}(indmax(i),1),IndEvent)==0
            IndEvent=cat(2,IndEvent,Distfrnorep{i}(indmax(i),1));
            %create new Result matrix containing only the brightest localization per ROI
            ResultEvent=cat(2,ResultEvent,Resultsortframermv2(:,Distfrnorep{i}(indmax(i),1)));
        end
    end
end
ResultEventFrNr=sortrows(ResultEvent',4)';
end