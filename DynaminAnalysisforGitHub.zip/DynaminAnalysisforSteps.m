% DYNAMINANALYSISFORSTEPS extracts latency and scission of dynamin
% relative to the stimulus frame in a series of microscopy images. It first
% extracts intensity traces from the image series, hands it over to
% AutoStepfinder, a previously published function (Leoff et al) detecting
% steps in 1D intensity traces, followed by filtering of traces to maximize
% the detection of real events and to reduce noise.

% threshold_int     intensity threshold for filtering, typically a
%                   threshold of 10 photons was used 
% binning_pf        temporal binning factor applied on the image stack 
%                   for peak finding, a value of 50 frames was used if an 
%                   optosplit was introduced into the lightpath; otherwise 
%                   a value of 100 frames was used
% binning_trace     temporal binning factor for trace analysis, typically 
%                   a value of 5 was used
% framerate         framerate of measurement, typically was set to 50Hz if
%                   an optosplit was introduced into the lightpath; 
%                   otherwise it was set to 100Hz
% ROIsize2          size of the cutout area in pixels, typically was set to
%                   3 pixels
% bl                number of baseline frames, typically was set to 500
%                   frames if an optosplit was introduced into the  
%                   lightpath; otherwise it was set to 1000 frames. Values
%                   have to be adapted for detection of spontaneous and 
%                   straddle events
% xPSF              vector containing fitting parameter for the PSF of the
%                   imaging system, for the Photometrics PRIME 95B 12bit
%                   camera the PSF fitting parameters were calibrated to be
%                   xPSF=[1.335912515528878 3.872168943713308
%                   4.062641868605175 1.003536526943182 0.025687196972689];
% DN2photon         camera-specific conversion factor transforming digital
%                   numbers (counts) into photon numbers, 
%                   DN2photon = 0.5905 for the Photometrics PRIME 95B 12bit
%                   camera
% threshtemplate    threshold for template matching algorithm, typically
%                   was set to 1
% dirStep           directory containing the AutoStepfinder as well as the
%                   DataDuster .fig and .m files, given as a string ('')
% analysismode      analysismode distinguishes between spontaneous or
%                   straddle events and post-stimulation events. Can either
%                   be 'spont/strad' or 'stim'

% foldername        directory containing the AutoStepfinder output, given
%                   as a string ('')
% filename          first part of the file name of the AutoStepfinder
%                   output (without enumeration in case of multiple ROIs).
%                   For the file 'cleaned_traceInt_poststim_medfilt_col_01_properties.mat' 
%                   filename is 'cleaned_traceInt_poststim_medfilt_col'.
%                   This automizes the reading-in of multiple traces with
%                   ascending numbering.
% Xmax              total number of movies analyzed in AutoStepfinder,
%                   typically 1
% N                 Highest trace number in the AutoStepfinder output
%                   folder (scalar for single movie, vector fur multiple
%                   movies)


%                   Code written by Julia Lehrich and Sai Krishnan,
%                   Matlab version R2019b, September 2024

%% get input variables
threshold_int = input('What is the intensity threshold for filtering? ');
binning_pf = input('What is the binning factor for peak finding? ');
binning_trace = input('What is the binning factor for trace analysis? ');
framerate = input('What is the framerate of measurement (in Hz)? ');
ROIsize2 = input('What is the size of the cutout area (in pixels)? ');
bl = input('What is the number of baseline frames? ');
xPSF = input('What are the PSF fitting parameters? ');
DN2photon = input('What is the camera conversion factor (digital counts to photons)? ');
threshtemplate = input('What is the threshold for template matching algorithm? '); 
dirStep = input('In which directory is the AutoStepfinder located? ');
Xmax = input('What is the total number of movies to be analyzed in AutoStepfinder? ');
analysismode = input('Shall spontaneous/straddle or post-stimulation events be analyzed? ');

%% first step: load stack of images
baseline=(bl*1/binning_pf);
[A] = imreadtiff;

%% grouped z-projection (mean and median)
%temporal binning for peak finding:
B=reshape(A,size(A,1),size(A,2),binning_pf,size(A,3)./binning_pf);
B_avg=squeeze(round(mean(B,3)));

%% background subtraction
stringcompare=strcmp('stim',analysismode);
if stringcompare==1
    bg_avg=round(mean(B_avg(:,:,1:baseline),3));
end
stringcompare=strcmp('spont/strad',analysismode);
if stringcompare==1
    bg_avg=round(mean(B_avg(:,:,baseline:end),3));
end
B_avg_bg=B_avg-bg_avg;

%% Mask generation
frames = single(round(mean(B_avg,3)));
frames = frames - single(min(min(min(frames))));
frames = single(frames) / single(max(max(max(frames))));
total_mean = mean(frames(:, :, :), 3);
t = total_mean;
level = graythresh(t);
maskT = imbinarize(t,level);
maskT = imfill(maskT,'holes');
mask_size = 2;
se = strel('disk', mask_size);
maskT = imopen(maskT, se);
maskT = imdilate(maskT, se);

%% Peak finding
[Resultsortall]=counthistwavelet(xPSF,B_avg_bg,ROIsize2,0,DN2photon,threshtemplate);
Resultsort=Resultsortall(:,find(Resultsortall(1,:)>threshold_int,1,'first'):end);
Resultsortframenr=sortrows(Resultsort',4)';
%Define analysis frames
stringcompare=strcmp('stim',analysismode);
if stringcompare==1
    Resultsortframe=Resultsortframenr(:,find(Resultsortframenr(4,:)>baseline-1,1,'first'):end);
end
stringcompare=strcmp('spont/strad',analysismode);
if stringcompare==1
    Resultsortframe=Resultsortframenr(:,1:find(Resultsortframenr(4,:)>1,1,'last'));
end

%% calculate proximity
[ResultEventFrNr]=Dynamin_proximity(Resultsortframe);

%% filter out localizations outside the mask
ResultEventfrnr=ResultEventFrNr;

for i=size(ResultEventfrnr,2):-1:1
cuti_mask=maskT(round(ResultEventfrnr(3,i))-(floor(ROIsize2/2)):round(ResultEventfrnr(3,i))+(floor(ROIsize2/2)),round(ResultEventfrnr(2,i))-(floor(ROIsize2/2)):round(ResultEventfrnr(2,i))+(floor(ROIsize2/2)),:);
  if sum(cuti_mask,'all')<=0
  ResultEventfrnr(:,i)=[];
  end
end

%% Cut out 3x3 px ROI for each event and generate traces
%temporal binning for trace generation:
B_2=reshape(A,size(A,1),size(A,2),binning_trace,size(A,3)./binning_trace);
B_avg_2=squeeze(round(mean(B_2,3)));

%generate traces from the filtered traces
cuti=zeros(ROIsize2,ROIsize2,size(B_avg_2,3),size(ResultEventfrnr,2));
trace=zeros(size(ResultEventfrnr,2),size(B_avg_2,3));
for i=1:size(ResultEventfrnr,2)
  cuti(:,:,:,i)=B_avg_2(round(ResultEventfrnr(3,i))-(floor(ROIsize2/2)):round(ResultEventfrnr(3,i))+(floor(ROIsize2/2)),round(ResultEventfrnr(2,i))-(floor(ROIsize2/2)):round(ResultEventfrnr(2,i))+(floor(ROIsize2/2)),:);
  trace(i,:)=sum(sum(cuti(:,:,:,i),1),2);
end

%generate traces from the filtered traces, sorted by intensity
ResultEventInt=sortrows(ResultEventfrnr',1)';
cutiInt=zeros(ROIsize2,ROIsize2,size(B_avg_2,3),size(ResultEventInt,2));
traceInt=zeros(size(ResultEventInt,2),size(B_avg_2,3));
for i=1:size(ResultEventInt,2)
  cutiInt(:,:,:,i)=B_avg_2(round(ResultEventInt(3,i))-(floor(ROIsize2/2)):round(ResultEventInt(3,i))+(floor(ROIsize2/2)),round(ResultEventInt(2,i))-(floor(ROIsize2/2)):round(ResultEventInt(2,i))+(floor(ROIsize2/2)),:);
  traceInt(i,:)=sum(sum(cutiInt(:,:,:,i),1),2);
end

%% generate traces for AutoStepfinder
traceInt_cor=traceInt(:,1:600)';
traceInt_cor_medfilt=medfilt1(traceInt_cor,2);
traceInt_cor_medfilt=traceInt_cor_medfilt(2:end,:);

%% apply AutoStepfinder
% save traceInt_poststim_medfilt as .txt file
writematrix(traceInt_cor_medfilt,strcat(num2str(Xmax),'.txt'),'Delimiter','tab');
dir=cd;

% move to the AutoStepfinder directory:
cd(dirStep);
% separate the individual traces with DataDuster and save to file as .txt
% file. A folder with the cleaned data will be generated in the file
% directory.
DataDuster

% To use DataDuster, apply the following settings:
% Run Mode: Single
% Columns to analyse: All columns
% Replace data with: Neighbor
pause

% Next, use AutoStepfinder.m.
cd(dirStep);
AutoStepfinder
% Use the following settings:
% Run Mode: Batch
% Iteration range: 20
% Time resolution: 1.0
% Acc. Threshold: 0.2
% S-Curves: Off
% User plot: Off
% Adv. Options: On
% Output files: Custom output & Properties
% File extension .mat
% Fitting: Mean
% Manual mode: Off
% Post Processing: Off
% Noise estimation: Off
% Error estimation: Off
pause
cd(dir);
%% Extract values from AutoStepfinder Properties and Concatenate each property in alignment with ResultEventInt
PropertiesName{1,1}='DwellTimeStepAfter';
PropertiesName{2,1}='DwellTimeStepBefore';
PropertiesName{3,1}='IndexStep';
PropertiesName{4,1}='StepSize';
PropertiesName{5,1}='Pathname';
PropertiesName{6,1}='MeasurementNumber';
PropertiesName{7,1}='TraceNumber';
PropertiesName{8,1}='framestart';
PropertiesName{9,1}='frameend';

foldername = input('What is the directory containing the AutoStepfinder output, given as a string? ');
N = input('What is the highest trace number in the AutoStepfinder output folder? ');
Properties=cell(9,0);

%load Properties from AutoStepfinder     
for j=1:Xmax
    for i=1:N(j)
        filename=strcat('cleaned_',num2str(j),'_col');
        if N(j)<99
            if i<10
                pathname=strcat(foldername,'\',filename,'_0',num2str(i),'_properties.mat');
            else
                pathname=strcat(foldername,'\',filename,'_',num2str(i),'_properties.mat');
            end
        else
            if i<10
                pathname=strcat(foldername,'\',filename,'_00',num2str(i),'_properties.mat');
            elseif (10<i) && (i<100)
                pathname=strcat(foldername,'\',filename,'_0',num2str(i),'_properties.mat');
            else
                pathname=strcat(foldername,'\',filename,'_',num2str(i),'_properties.mat');
            end
        end
        try %not all measurement numbers (i.e. pathnames) exist. To avoid errors when attempting to read nonexistent path, use try ... catch.
            load(pathname)
            n=size(Properties,2);
            Properties{1,n+1}=DwellTimeStepAfter;
            Properties{2,n+1}=DwellTimeStepBefore;
            Properties{3,n+1}=IndexStep;
            Properties{4,n+1}=StepSize;
            Properties{5,n+1}=pathname;
            Properties{6,n+1}=j;
            Properties{7,n+1}=i;
            clear DwellTimeStepAfter DwellTimeStepBefore filename IndexStep LevelAfter LevelBefore StepError StepSize TimeStep;
        catch
        end
    end
end
%% Use Properties values to Filter the dynamin events in ResultEventInt
%change the variables in filtersteps for optosplit and non-optosplit
[Properties_final]=filterSteps_3(Properties);

for i=1:size(Properties_final,2)
    tracenumber(i)=Properties_final{7,i};
end
ResultEventInt_good=ResultEventInt(:,tracenumber);
Properties_final_extract=cell2mat(Properties_final([7,8,9,],:)) ;
ResultEventInt_good = vertcat(ResultEventInt_good,Properties_final_extract);

%% Generating selected traces and event properties after filtering
%extract the eventstart and eventend values
framestart_orig=ResultEventInt_good(6,:)';
frameend_orig=ResultEventInt_good(7,:)';

stringcompare=strcmp('stim',analysismode);
if stringcompare==1
    framestart=framestart_orig+(baseline*binning_pf*(1/binning_trace))-(bl/binning_trace);
    frameend=frameend_orig+(baseline*binning_pf*(1/binning_trace))-(bl/binning_trace);
end
stringcompare=strcmp('spont/strad',analysismode);
if stringcompare==1
    framestart=framestart_orig;
    frameend=frameend_orig;
end

%duration is the length of the window defined in the GUI (given in s), filter out very short events:
duration=(frameend-framestart)./((1/binning_trace)*framerate);

stringcompare=strcmp('stim',analysismode);
if stringcompare==1
    %latency is the delay between the stimulus and the onset of the event, i.e.
    %the position of the start marker defined in the GUI. latency is given in s
    latency=(framestart./((1/binning_trace)*framerate))-baseline;
    %tauendo is the time between stimulation and fission (i.e. end point in GUI)
    tauendo=(frameend./((1/binning_trace)*framerate))-baseline;
end

stringcompare=strcmp('spont/strad',analysismode);
if stringcompare==1
    latency=(framestart./((1/binning_trace)*framerate));
    tauendo=(frameend./((1/binning_trace)*framerate));
end

%alternative to histogram plot:
tauendo_sort=sort(tauendo);
tauendo_Sort=cat(1,0,tauendo_sort);
tauendo_events=length(tauendo):-1:0;
%figure, plot(tauendo_Sort,tauendo_events)

%% Matrix of extracted and sorted event properties post stim

Eventproperties_stim=[];
Eventproperties_spont=[];
Eventproperties_strad=[];
stringcompare=strcmp('stim',analysismode);
if stringcompare==1
    Eventproperties=[duration,tauendo,latency,frameend,tracenumber'];
    H = (find (Eventproperties(:,3)>(bl/framerate)))';
    Eventproperties_stim = Eventproperties(H,:);
    Eventproperties_stim = sortrows(Eventproperties_stim,[1,2,3,4,5]);
    
    % Generate the final traces post-stimulus
    tracenumber_new_stim =sort(Eventproperties_stim(:,5)');
    Eventproperties_cor_stim=sortrows(Eventproperties_stim,[5]);
    frameend_cor_stim=Eventproperties_cor_stim(:,4);
    ResultEventInt_good_cor_stim=ResultEventInt(:,tracenumber_new_stim);
    cuti=zeros(ROIsize2,ROIsize2,size(B_avg_2,3),size(ResultEventInt_good_cor_stim,2));
    traceInt_good_stim=zeros(size(ResultEventInt_good_cor_stim,2),size(B_avg_2,3));
    for i=1:size(ResultEventInt_good_cor_stim,2)
        cuti(:,:,:,i)=B_avg_2(round(ResultEventInt_good_cor_stim(3,i))-(floor(ROIsize2/2)):round(ResultEventInt_good_cor_stim(3,i))+(floor(ROIsize2/2)),round(ResultEventInt_good_cor_stim(2,i))-(floor(ROIsize2/2)):round(ResultEventInt_good_cor_stim(2,i))+(floor(ROIsize2/2)),:);
        traceInt_good_stim(i,:)=sum(sum(cuti(:,:,:,i),1),2);
    end
end

stringcompare=strcmp('spont/strad',analysismode);
if stringcompare==1
    Eventproperties=[duration,tauendo,latency,frameend,tracenumber'];
    H = (find (Eventproperties(:,3)>10))';%for spont to exclude post stim events
    Eventproperties_stim = Eventproperties(H,:);
    Eventproperties(H,:)=[];
    G = (find (Eventproperties(:,4)>(bl/binning_trace)))';
    Eventproperties_strad = Eventproperties(G,:);
    Eventproperties(G,:)=[];
    Eventproperties_spont=sortrows(Eventproperties,[1,2,3,4,5]); %final spont
    Eventproperties_strad =sortrows(Eventproperties_strad,[1,2,3,4,5]);
    
    % Generate the final fully filtered properties and use it to generate traces
    tracenumber_new =sort(Eventproperties_spont(:,5)');
    Eventproperties_spont=sortrows(Eventproperties_spont,5);
    frameend_spont=Eventproperties_spont(:,4);
    ResultEventInt_good_spont=ResultEventInt(:,tracenumber_new);
    
    % Generate the final traces for spontaneous events
    cuti=zeros(ROIsize2,ROIsize2,size(B_avg_2,3),size(ResultEventInt_good_spont,2));
    traceInt_good_spont=zeros(size(ResultEventInt_good_spont,2),size(B_avg_2,3));
    for i=1:size(ResultEventInt_good_spont,2)
        cuti(:,:,:,i)=B_avg_2(round(ResultEventInt_good_spont(3,i))-(floor(ROIsize2/2)):round(ResultEventInt_good_spont(3,i))+(floor(ROIsize2/2)),round(ResultEventInt_good_spont(2,i))-(floor(ROIsize2/2)):round(ResultEventInt_good_spont(2,i))+(floor(ROIsize2/2)),:);
        traceInt_good_spont(i,:)=sum(sum(cuti(:,:,:,i),1),2);
    end

    % Generate the final traces for straddle events
    tracenumber_new_strad =sort(Eventproperties_strad(:,5)');
    Eventproperties_cor_strad=sortrows(Eventproperties_strad,[5]);
    frameend_cor_strad=Eventproperties_cor_strad(:,4);
    ResultEventInt_good_cor_strad=ResultEventInt(:,tracenumber_new_strad);
    cuti=zeros(ROIsize2,ROIsize2,size(B_avg_2,3),size(ResultEventInt_good_cor_strad,2));
    traceInt_good_strad=zeros(size(ResultEventInt_good_cor_strad,2),size(B_avg_2,3));
    for i=1:size(ResultEventInt_good_cor_strad,2)
    cuti(:,:,:,i)=B_avg_2(round(ResultEventInt_good_cor_strad(3,i))-(floor(ROIsize2/2)):round(ResultEventInt_good_cor_strad(3,i))+(floor(ROIsize2/2)),round(ResultEventInt_good_cor_strad(2,i))-(floor(ROIsize2/2)):round(ResultEventInt_good_cor_strad(2,i))+(floor(ROIsize2/2)),:);
    traceInt_good_strad(i,:)=sum(sum(cuti(:,:,:,i),1),2);
    end
end

%% traceInt_good_all is the truncated version of the traces for averaging
stringcompare=strcmp('stim',analysismode);
if stringcompare==1
    traceInt_good_all=zeros(size(traceInt_good_stim,1),240);

    for i=1:size(traceInt_good_stim,1)
        if frameend_cor_stim(i)+15<=size(traceInt_good_stim,2)
            traceInt_good_all(i,:)=traceInt_good_stim(i,frameend_cor_stim(i)-224:frameend_cor_stim(i)+15);
        else
            traceInt_good_all(i,:)=[];
        end
    end
%% average events
% perform a manual check for event selection in Eventproperties_cor with
% very long (>10) or short (<2) durations
traceInt_good_avg=mean(traceInt_good_all,1);
figure, plot(traceInt_good_avg)
end